import os

MAX_FAILED_ATTEMPTS = 3

def setup():
    print("Welcome to AlphaOS Setup!")
    password = input("Enter a new password: ")
    save_password(password)
    print("Setup complete!")

def save_password(password):
    with open("AlphaData.txt", "w") as file:
        file.write(password)

def read_password():
    with open("AlphaData.txt", "r") as file:
        password = file.read().strip()
        return password

def clear_file_content(file_path):
    with open(file_path, "w") as file:
        file.write("")

def is_empty_file(file_path):
    return os.path.exists(file_path) and os.path.getsize(file_path) == 0

def show_boot_screen():
    print("Welcome to AlphaOS Boot Screen!")
    print("Press Enter to continue...")
    input()

def show_apps_menu(username):
    print(f"AlphaOS Apps Menu for {username}:\n")
    print("1. Calculator")
    print("2. Notepad")
    print("3. File Explorer")
    choice = input("Enter the number of the app you want to open: ")
    if choice == "1":
        os.system("python Calculator.py")
    elif choice == "2":
        os.system("python Notepad.py")
    elif choice == "3":
        os.system("python FileExplorer.py")
    else:
        print("Invalid choice!")

def show_security_lock():
    if not os.path.exists("AlphaData.txt"):
        print("Missing file: AlphaData.txt")
        return
    if is_empty_file("AlphaData.txt"):
        setup()

    attempts = 0
    while attempts < MAX_FAILED_ATTEMPTS:
        print("AlphaOS Security Lock Screen")
        saved_password = read_password()
        password = input("Enter your password: ")
        if password == saved_password:
            print("Access granted!")
            username = saved_password  # Use the password as the username for simplicity
            if not os.path.exists(username):
                os.mkdir(username)
            show_apps_menu(username)
            break
        else:
            attempts += 1
            print("Access denied!")
            if attempts >= MAX_FAILED_ATTEMPTS:
                print("Too many failed attempts. Resetting system...")
                clear_file_content("AlphaData.txt")
                print("AlphaOS system reset complete.")

if __name__ == "__main__":
    show_boot_screen()
    show_security_lock()
