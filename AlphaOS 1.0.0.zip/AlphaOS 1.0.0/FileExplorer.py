import os

def file_explorer():
    print("Welcome to File Explorer!\n")
    current_directory = os.getcwd()
    
    while True:
        print("Files and directories in", current_directory)
        files = os.listdir(current_directory)
        for index, item in enumerate(files, start=1):
            print(f"{index}. {item}")
        
        print("\nOptions:")
        print("1. Open file or directory")
        print("2. Go to parent directory")
        print("3. Exit")
        
        choice = input("Please select an option (1/2/3): ")
        
        if choice == "1":
            selection = int(input("Enter the number of the file/directory to open: ")) - 1
            selected_item = files[selection]
            if os.path.isdir(selected_item):
                current_directory = os.path.join(current_directory, selected_item)
            else:
                with open(selected_item, "r") as file:
                    content = file.read()
                    print("\nFile content:\n", content)
        elif choice == "2":
            current_directory = os.path.dirname(current_directory)
        elif choice == "3":
            break
        else:
            print("Invalid choice!")

file_explorer()
