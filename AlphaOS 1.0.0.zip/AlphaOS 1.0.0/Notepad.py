def notepad():
    print("Welcome to Notepad!\n")
    notes = ""
    while True:
        print("Your notes:\n", notes)
        print("Options:")
        print("1. Write a note")
        print("2. Save notes")
        print("3. Open saved notes")
        print("4. Exit")
        
        choice = input("Please select an option (1/2/3/4): ")
        
        if choice == "1":
            note = input("Enter your note: ")
            notes += note + "\n"
        elif choice == "2":
            filename = input("Enter the filename to save notes: ")
            with open(filename, "w") as file:
                file.write(notes)
            print("Notes saved.")
        elif choice == "3":
            filename = input("Enter the filename to open: ")
            with open(filename, "r") as file:
                notes = file.read()
            print("Notes opened.")
        elif choice == "4":
            break
        else:
            print("Invalid choice!")

notepad()
