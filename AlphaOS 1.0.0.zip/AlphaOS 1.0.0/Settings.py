import os
import time

def settings():
    print("Welcome to Settings!\n")
    while True:
        print("Options:")
        print("1. Change password")
        print("2. Reset system")
        print("3. Clock")
        print("4. About")
        print("5. Restart your computer")
        print("6. Go back to main menu")
        
        choice = input("Please select an option (1/2/3/4/5/6): ")
        
        if choice == "1":
            new_password = input("Enter a new password: ")
            save_password(new_password)
            print("Password changed.")
        elif choice == "2":
            clear_file_content("AlphaData.txt")
            print("System reset complete.")
        elif choice == "3":
            show_clock()
        elif choice == "4":
            show_about()
        elif choice == "5":
            restart_computer()
        elif choice == "6":
            break
        else:
            print("Invalid choice!")

def show_clock():
    current_time = time.strftime("%Y-%m-%d %H:%M:%S")
    print("Current time:", current_time)

def show_about():
    print("AlphaOS - A simple operating system developed with Python.")
    print("Version: 1.0")
    print("Developed by: Your Name")

def restart_computer():
    print("Restarting your computer...")
    os.system("shutdown /r /t 1")

settings()
